from django.contrib import admin
from blog.models import Post

# Register your models here.
class PostModelAdmin(admin.ModelAdmin):
    list_display = ('title', 'update', 'timestamp', 'file_for_content', 'quantity_content', 'topic')
    list_display_links = ('update', )
    list_editable = ('title', 'topic')
    list_filter = ('update', 'timestamp', 'title')
    search_fields = ['title']  #шукає пост по назві тайтл
    readonly_fields = ('file_for_content', ) #зазначений аргумент не буде застосовуватись до редагування




admin.site.register(Post, PostModelAdmin)