from django.contrib import admin
from publication.models import Image

# Register your models here.
class ImageModelAdmin(admin.ModelAdmin):
    list_display = ('file', 'text', 'update')
    list_display_links = ('update', )
    list_editable = ('text', )
    list_filter = ('file', 'text')
    search_fields = ['file']





admin.site.register(Image, ImageModelAdmin)



