from django.shortcuts import render
from django.http import HttpResponse


def create_image(request):
    return render(request, 'index.html')

def archive_image(request):
    return render(request, 'index_two.html')
def page_publication(request):
    return HttpResponse('<h2>This page is for publication image</h2') #домашня сторінка для розділу публікації