from django.db import models

class Image(models.Model):
    file = models.FileField()
    text = models.TextField()
    update = models.DateTimeField(auto_now=True)



    def __str__(self):
        return self.text


